import streamlit as st
import requests
from bs4 import BeautifulSoup
import time
import random
import pandas as pd
import string
import nltk
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
from nltk.tokenize import word_tokenize
from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
from transformers import pipeline

# Hide Streamlit header and footer
st.markdown("""<style>
    header {visibility: hidden;}
    footer {visibility: hidden;}
    </style>""", unsafe_allow_html=True)


# NLTK Downloads
nltk.download('stopwords')
nltk.download('punkt')
nltk.download('wordnet')

# Initialize lemmatizer
lemmatizer = WordNetLemmatizer()

# Define fake user agents list
fake_user_agents = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.114 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:89.0) Gecko/20100101 Firefox/89.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:89.0) Gecko/20100101 Firefox/89.0",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36 Edg/91.0.864.64",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.1.1 Safari/605.1.15",
    "Mozilla/5.0 (Linux; Android 10; SM-G975F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Mobile Safari/537.36",
    "Mozilla/5.0 (Linux; Android 11; Pixel 4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Mobile Safari/537.36",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 14_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0 Mobile/15E148 Safari/604.1",
    "Mozilla/5.0 (iPad; CPU OS 14_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.0 Mobile/15E148 Safari/604.1",
    "Mozilla/5.0 (Android 10; Mobile; rv:89.0) Gecko/89.0 Firefox/89.0",
    "Mozilla/5.0 (Android 11; Mobile; rv:89.0) Gecko/89.0 Firefox/89.0",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 14_6 like Mac OS X) AppleWebKit/537.36 (KHTML, like Gecko) CriOS/91.0.4472.124 Mobile/15E148 Safari/537.36",
    "Mozilla/5.0 (iPad; CPU OS 14_6 like Mac OS X) AppleWebKit/537.36 (KHTML, like Gecko) CriOS/91.0.4472.124 Mobile/15E148 Safari/537.36",
]

# Functions for scraping, cleaning, and analysis
def fetch(url, headers):
    response = requests.get(url, headers=headers)
    if response.status_code == 200:
        return response.text
    else:
        st.warning(f"Failed to retrieve page: {response.status_code}")
        return None

def parse(page_content):
    soup = BeautifulSoup(page_content, 'html.parser')
    reviews = []
    review_divs = soup.find_all('div', {'data-hook': 'review'})
    for div in review_divs:
        title = div.find('a', {'data-hook': 'review-title'}).find_all('span')[2].get_text(strip=True)
        body = div.find('span', {'data-hook': 'review-body'}).get_text(strip=True)
        reviews.append({'review_heading': title, 'review_body': body})
    return reviews

def scrape(url, headers, delay=2):
    content = fetch(url, headers)
    if not content:
        return []
    reviews = parse(content)
    time.sleep(random.uniform(delay, delay + 2))
    return reviews

def clean(review):
    review = review.lower()
    review = review.translate(str.maketrans('', '', string.punctuation))
    review = ''.join([i for i in review if not i.isdigit()])
    stop_words = set(stopwords.words('english'))
    words = word_tokenize(review)
    cleaned_review = ' '.join([lemmatizer.lemmatize(word) for word in words if word not in stop_words])
    return cleaned_review

def clean_data(data):
    data['cleaned_review'] = data['review_text'].apply(clean)
    return data[['review_text', 'cleaned_review']]

def create_dataset(reviews):
    data = pd.DataFrame(reviews)
    data['review_text'] = data['review_heading'] + ' ' + data['review_body']
    data = data.drop(columns=['review_heading', 'review_body'])
    data = clean_data(data)
    return data

def heuristic_label(review):
    stop_words = set(stopwords.words('english'))
    words = word_tokenize(review)

    if len(words) < 5:
        return 1

    if len(set(words)) / len(words) < 0.5:
        return 2

    promotional_keywords = ['buy', 'discount', 'offer', 'sale', 'amazing', 'cheap', 'best']
    if any(keyword in words for keyword in promotional_keywords):
        return 3

    first_person_pronouns = ['i', 'me', 'my', 'mine', 'we', 'us', 'our', 'ours']
    if len([word for word in words if word in first_person_pronouns]) / len(words) > 0.1:
        return 4

    return 0

def sentiment(data):
    analyzer = SentimentIntensityAnalyzer()
    data['sentiment_score'] = data['review_text'].apply(lambda text: analyzer.polarity_scores(text)['compound'])
    return data

def summarize_text(text, summarizer):
    input_length = len(text.split())
    max_length = input_length // 2
    min_length = 10
    try:
        summary = summarizer(text, max_length=max_length, min_length=min_length, do_sample=False)
        return summary[0]['summary_text']
    except Exception as e:
        print(f"Error summarizing text: {e}")
        return text

def chunk_reviews(reviews, chunk_size):
    for i in range(0, len(reviews), chunk_size):
        yield reviews[i:i + chunk_size]

def summarize_reviews(data, summarizer):
    positive_reviews = data[(data['sentiment_score'] >= 0) & (data['is_fake'] == 0)]['review_text'].tolist()
    negative_reviews = data[(data['sentiment_score'] <= 0) & (data['is_fake'] == 0)]['review_text'].tolist()

    chunk_size = 5

    positive_summaries = []
    for chunk in chunk_reviews(positive_reviews, chunk_size):
        combined_text = " ".join(chunk)
        summary = summarize_text(combined_text, summarizer)
        positive_summaries.append(summary)

    negative_summaries = []
    for chunk in chunk_reviews(negative_reviews, chunk_size):
        combined_text = " ".join(chunk)
        summary = summarize_text(combined_text, summarizer)
        negative_summaries.append(summary)

    display_summaries(positive_summaries, negative_summaries)

def display_summaries(positive_summaries, negative_summaries):
    st.write('## Positive Review Summaries')
    if positive_summaries[:5]:
        summaries = positive_summaries[:5][0].split('.')
        for summary in summaries:
            if summary != '':
                st.write(summary.strip().capitalize() + '.')
    else:
        st.write("No positive reviews")

    st.write('## Negative Review Summaries')
    if negative_summaries[:5]:
        summaries = negative_summaries[:5][0].split('.')
        for summary in summaries:
            if summary != '':
                st.write(summary.strip().capitalize() + '.')
    else:
        st.write("No negative reviews")


# Layout
st.markdown(
    """
    <div style="text-align: center;">
        <h1 style = "color:red;">Product Review Summarizer <small style = "color:red; vertical-align: middle;">[prototype]</small></h1>
    </div>
    """, unsafe_allow_html=True
)

st.markdown(
    """
    <style>
    .stTextInput div {
        width: 100%;
        margin: 0 auto;
    }
    .stButton button {
        width: 30%;
        margin: 20px auto; /* Added margin for spacing */
        display: block;
    }
    </style>
    """, unsafe_allow_html=True
)

product_url = st.text_input("Enter Amazon URL")

if st.button("Submit"):
    if product_url.startswith("https://www.amazon.in"):
        final_url = product_url
    elif product_url.startswith("https://amzn.in/"):
        response = requests.get(product_url)
        final_url = response.url
    else:
        st.warning("Invalid URL. Please enter a valid URL.")
        final_url = None
    if final_url:
        if final_url.startswith("https://www.amazon.in"):
            with st.spinner('Rendering Summaries'):
                url = final_url.split('?')[0]
                headers = {"User-Agent": random.choice(fake_user_agents)}
                url = url.replace('dp', 'product-reviews')
                reviews = scrape(url, headers)
                if reviews:
                  data = create_dataset(reviews)
                  data['is_fake'] = data['cleaned_review'].apply(heuristic_label)
                  data = sentiment(data)
                  summarizer = pipeline("summarization", model="t5-base")
                  summarize_reviews(data, summarizer)
                else:
                  st.warning("Unable to fetch. Please try again")

        else:
            st.write("Invalid Amazon URL")
